import pathlib

import gousto_test

# Project paths
PROJECTSPATH = pathlib.Path(gousto_test.__file__).resolve().parent
